function calculateScore() {
    let input = prompt(
        "Nhập các phần tử của mảng (cách nhau bởi dấu phẩy, ví dụ: 2,4,6,1,3,5), tối đa 20 phần tử:"
    );
    let arr = input
        .split(",")
        .map(Number)
        .filter((num) => !isNaN(num));

    if (arr.length > 20) {
        alert("Số lượng phần tử vượt quá 20. Vui lòng nhập lại!");
        return;
    }

    let display = document.getElementById("resultDisplay");
    display.innerHTML = "<h2>Mảng hiển thị dọc:</h2>";
    arr.forEach((num) => (display.innerHTML += num + "<br>"));

    let sumEven = arr.filter((num) => num % 2 === 0).reduce((a, b) => a + b, 0);
    let sumOdd = arr.filter((num) => num % 2 !== 0).reduce((a, b) => a + b, 0);

    display.innerHTML += "<p>Tổng các số chẵn: " + sumEven + "</p>";
    display.innerHTML += "<p>Tổng các số lẽ: " + sumOdd + "</p>";
}

document.querySelector("button").addEventListener("click", calculateScore);
