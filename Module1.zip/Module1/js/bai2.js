function checkString() {
    const input = document.getElementById("inputString").value;
    const hasUpperCase = /[A-Z]/.test(input);

    if (input.trim() === "") {
        document.getElementById("result").innerText =
            "Không có ký tự trong chuỗi.";
    } else if (!hasUpperCase) {
        document.getElementById("result").innerText =
            "Chuỗi không chứa ký tự in hoa.";
    } else {
        const upperCaseCount = (input.match(/[A-Z]/g) || []).length;
        document.getElementById(
            "result"
        ).innerText = `Chuỗi chứa ${upperCaseCount} ký tự in hoa.`;
    }
}
