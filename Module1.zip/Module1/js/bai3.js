function sortArray() {
    const input = document.getElementById("inputArray").value;
    const numbers = input
        .split(",")
        .map((num) => parseFloat(num.trim()))
        .filter((num) => !isNaN(num));

    if (numbers.length === 0) {
        document.getElementById("result").innerText = "Không có số để sắp xếp.";
    } else {
        numbers.sort((a, b) => a - b);
        document.getElementById("result").innerText =
            "Mảng đã sắp xếp: " + numbers.join(", ");
    }
}
