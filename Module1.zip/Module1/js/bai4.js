// ===== Lớp Phone với getter/setter và toString =====
class Phone {
    #id;
    #name;
    #brand;
    #price;

    constructor(id, name, brand, price) {
        this.id = id;
        this.name = name;
        this.brand = brand;
        this.price = Number(price);
    }

    // getters
    get id() {
        return this.#id;
    }
    get name() {
        return this.#name;
    }
    get brand() {
        return this.#brand;
    }
    get price() {
        return this.#price;
    }

    // setters (kèm kiểm tra đơn giản)
    set id(v) {
        if (!v || String(v).trim() === "")
            throw new Error("Mã điện thoại không hợp lệ");
        this.#id = String(v).trim();
    }
    set name(v) {
        if (!v || String(v).trim() === "") throw new Error("Tên không hợp lệ");
        this.#name = String(v).trim();
    }
    set brand(v) {
        if (!v || String(v).trim() === "") throw new Error("Hãng không hợp lệ");
        this.#brand = String(v).trim();
    }
    set price(v) {
        const n = Number(v);
        if (!Number.isFinite(n) || n < 0)
            throw new Error("Giá phải là số không âm");
        this.#price = n;
    }

    toString() {
        return `${this.#id} - ${this.#name} (${
            this.#brand
        }) : ${this.#price.toLocaleString("vi-VN")}₫`;
    }
}

// ===== Dữ liệu mẫu ban đầu =====
let phones = [
    new Phone("IP15PM-256", "iPhone 15 Pro Max", "Apple", 32990000),
    new Phone("S24U-256", "Galaxy S24 Ultra", "Samsung", 28990000),
    new Phone("XM13-128", "Xiaomi 13", "Xiaomi", 11990000),
    new Phone("P8-128", "Pixel 8", "Google", 15990000),
];

// ===== Tiện ích: sắp xếp theo tên (vi-VN) và render bảng =====
function sortByName(a, b) {
    // localeCompare để sắp đúng tiếng Việt
    return a.name.localeCompare(b.name, "vi", { sensitivity: "base" });
}

const $tbody = document.getElementById("phone-tbody");
function render() {
    phones.sort(sortByName);
    if (phones.length === 0) {
        $tbody.innerHTML = `<tr><td colspan="4" class="empty">Chưa có dữ liệu</td></tr>`;
        return;
    }
    $tbody.innerHTML = phones
        .map(
            (p) => `
    <tr>
      <td>${escapeHtml(p.id)}</td>
      <td>${escapeHtml(p.name)}</td>
      <td>${escapeHtml(p.brand)}</td>
      <td class="right">${p.price.toLocaleString("vi-VN")}₫</td>
    </tr>
  `
        )
        .join("");
}

// Chống chèn HTML
function escapeHtml(s) {
    return String(s)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

// ===== Xử lý form thêm mới =====
const $form = document.getElementById("phone-form");
const $reset = document.getElementById("reset");

$form.addEventListener("submit", (e) => {
    e.preventDefault();

    const id = document.getElementById("id").value.trim();
    const name = document.getElementById("name").value.trim();
    const brand = document.getElementById("brand").value.trim();
    const price = document.getElementById("price").value;

    // kiểm tra trùng ID
    if (phones.some((p) => p.id.toLowerCase() === id.toLowerCase())) {
        alert("Mã điện thoại đã tồn tại. Vui lòng nhập mã khác.");
        return;
    }

    try {
        const phone = new Phone(id, name, brand, price);
        phones.push(phone);
        render(); // danh sách mới sau khi thêm
        $form.reset();
        document.getElementById("id").focus();
    } catch (err) {
        alert(err.message);
    }
});

$reset.addEventListener("click", () => $form.reset());

// Render lần đầu
render();
